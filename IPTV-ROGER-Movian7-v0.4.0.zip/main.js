/* IPTV ROGER 0.4.0 - Movian / M7 (PS3)
 * Admite M3U y Xtream Codes (Player API). API v2, JavaScript ES5.
 * No contiene playlists ni servicios preconfigurados.
 */
var page = require('movian/page');
var service = require('movian/service');
var settings = require('movian/settings');
var http = require('movian/http');
var store = require('movian/store').create('cineiptv-favorites-v1');
var PREFIX = 'cineiptv';
var ICON = Plugin.path + 'assets/icon.png';
var BG = Plugin.path + 'assets/background.png';
var ART = {tv:Plugin.path+'assets/tv.png', movies:Plugin.path+'assets/movies.png', series:Plugin.path+'assets/series.png',
  favs:Plugin.path+'assets/favs.png', lists:Plugin.path+'assets/lists.png',test:Plugin.path+'assets/test.png',
  update:Plugin.path+'assets/update.png',info:Plugin.path+'assets/info.png'};
var LIMIT = 15000; // Limite para evitar quedarse sin memoria en PS3
var playlists = [];
var cache = [null,null,null];
var xcaches = [null,null,null];
for (var nn=0;nn<3;nn++) playlists.push({name:'Mi lista '+(nn+1),url:'',server:'',user:'',pass:'',liveFmt:'ts'});

function strip(s) {return String(s===null||typeof s==='undefined'?'':s).replace(/^\s+|\s+$/g,'');}
function enc(s) {return encodeURIComponent(String(s));}
function dec(s) {try{return decodeURIComponent(s);}catch(e){return s;}}
function isHttp(s) {return /^https?:\/\//i.test(strip(s));}
function meta(t,icon,desc) {var m={title:strip(t),description:desc||''};if(icon)m.icon=icon;return m;}
function startPage(p,t) {
  p.type='directory';p.contents='items';p.metadata.title=t;p.metadata.logo=ICON;
  p.metadata.background=BG;
  try{p.model.contents='grid';}catch(e){}
  p.entries=0;
}
function addDir(p,url,t,d,icon){p.appendItem(url,'directory',meta(t,icon||ICON,d));p.entries++;}
function addSep(p,t,d){p.appendItem('', 'separator', meta(t,null,d));}
function addVideo(p,item,url,fromFav){
  if(!item || !item.url)return;
  var obj=p.appendItem(url,'video',meta(item.title,item.logo||ICON,item.group||''));
  if(obj && typeof obj.addOptAction==='function') {
    if(fromFav)obj.addOptAction('Quitar de favoritos',function(){delFavorite(item.url);});
    else obj.addOptAction('Agregar a favoritos',function(){addFavorite(item);});
  }
  p.entries++;
}
function paginate(p,arr,fn){
  var pos=0;
  function next(){var end=Math.min(arr.length,pos+70);while(pos<end){fn(arr[pos],pos);pos++;}p.loading=false;return pos<arr.length;}
  if(next())p.paginator=next;
}
function playVideo(p,item,route){
  if(!item || !isHttp(item.url) && !/^rt[ms]p:\/\//i.test(item.url))throw new Error('URL de video no valida.');
  p.type='video';
  var u=item.url;
  if(/\.m3u8(?:\?|$)/i.test(u)&&!/^hls:/i.test(u))u='hls:'+u;
  p.source='videoparams:'+JSON.stringify({title:item.title,icon:item.logo||ICON,canonicalUrl:route,
    sources:[{url:u}],no_subtitle_scan:true,no_fs_scan:true});
  p.loading=false;
}
function favs(){try{var v=JSON.parse(store.items||'[]');return v&&v.length?v:[];}catch(e){return [];}}
function addFavorite(item){var v=favs();for(var i=0;i<v.length;i++)if(v[i].url===item.url)return;
  if(v.length>=200)v.shift();v.push(item);store.items=JSON.stringify(v);}
function delFavorite(u){var v=favs(),a=[];for(var i=0;i<v.length;i++)if(v[i].url!==u)a.push(v[i]);store.items=JSON.stringify(a);}
function reset(n){cache[n]=null;xcaches[n]=null;}

// Analiza URLs habituales Xtream: /get.php?username=...&password=...&type=m3u_plus
function queryParam(url,key){
  var re=new RegExp('[?&]'+key+'=([^&#]*)','i'),m=re.exec(url);
  if(!m)return '';
  return dec(m[1].replace(/\+/g,' '));
}
function baseUrl(u){
  u=strip(u).replace(/\?.*$/,'').replace(/#.*$/,'').replace(/\/+$/,'');
  return u.replace(/\/(?:get|player_api)\.php$/i,'');
}
function config(n){
  var l=playlists[n], server=strip(l.server),user=strip(l.user),pass=strip(l.pass),url=strip(l.url);
  if(server&&user&&pass){return {mode:'xtream',base:baseUrl(server),user:user,pass:pass,liveFmt:l.liveFmt};}
  if(isHttp(url)&&/\/(?:get|player_api)\.php(?:\?|$)/i.test(url)){
    var u=queryParam(url,'username'),pw=queryParam(url,'password');
    if(u&&pw)return {mode:'auto',base:baseUrl(url),user:u,pass:pw,url:url,liveFmt:l.liveFmt};
  }
  return {mode:'m3u',url:url};
}
function signature(c){return c.mode+'|'+(c.base||'')+'|'+(c.user||'')+'|'+(c.pass||'')+'|'+(c.url||'');}
function xcache(n,c){var s=signature(c);if(!xcaches[n]||xcaches[n].sig!==s)
  xcaches[n]={sig:s,mode:null,categories:{},lists:{},series:{}};
  return xcaches[n];
}
function apiUrl(c,action,more){
  var u=c.base+'/player_api.php?username='+enc(c.user)+'&password='+enc(c.pass);
  if(action)u+='&action='+enc(action);
  if(more)for(var k in more)if(more.hasOwnProperty(k))u+='&'+enc(k)+'='+enc(more[k]);
  return u;
}
function fetchJSON(u){
  var raw=http.request(u,{headers:{'User-Agent':'Movian/7 IPTVRoger/0.4.0'}}).toString();
  return JSON.parse(raw);
}
function xtCall(c,action,extra){
  try{return fetchJSON(apiUrl(c,action,extra));}
  catch(e){throw new Error('No se pudo consultar Xtream. Revisa servidor, credenciales y conexion.');}
}
function kindAction(kind,what){
  var name=kind==='live'?'live':(kind==='movies'?'vod':'series');
  if(what==='categories')return 'get_'+name+'_categories';
  return kind==='series'?'get_series':('get_'+name+'_streams');
}
function xtCategories(n,c,kind){
  var x=xcache(n,c),key=kind;
  if(x.categories[key])return x.categories[key];
  var arr=xtCall(c,kindAction(kind,'categories'));
  if(!arr||Object.prototype.toString.call(arr)!=='[object Array]')throw new Error('El servidor no devolvio categorias Xtream validas.');
  x.categories[key]=arr;return arr;
}
function resolveMode(n){
  var c=config(n),x=xcache(n,c);
  if(c.mode==='xtream')return 'xtream';
  if(c.mode==='m3u')return 'm3u';
  if(x.mode)return x.mode;
  try{xtCategories(n,c,'live');x.mode='xtream';}
  catch(e){try{xtCategories(n,c,'movies');x.mode='xtream';}catch(e2){
    try{xtCategories(n,c,'series');x.mode='xtream';}catch(e3){x.mode='m3u';}
  }}
  return x.mode;
}
function getAttribute(line,key){
  var re=new RegExp('(?:^|\\s)'+key+'\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\'|([^\\s,]+))','i');
  var m=re.exec(line);return m?(m[1]||m[2]||m[3]||''):'';
}
function guessKind(group,t,url){
  var s=(group+' '+t).toLowerCase();
  if(/serie|series|temporada|capitulo|capítulo|episode|season|s\d\de\d\d/i.test(s)||/\/series\//i.test(url))return 'series';
  if(/pelicula|película|movie|movies|cine|filme|film|vod/i.test(s)||/\/movie\//i.test(url))return 'movies';
  return 'live';
}
function parseM3U(raw){
  var lines=String(raw||'').replace(/^\uFEFF/,'').replace(/\r/g,'').split('\n');
  if(lines.length<2||!/^\s*#EXTM3U/i.test(lines[0]))throw new Error('El enlace no devolvio una lista #EXTM3U valida.');
  var arr=[],info=null,group='';
  for(var i=0;i<lines.length&&arr.length<LIMIT;i++){
    var line=strip(lines[i]);if(!line)continue;
    if(line.indexOf('#EXTINF')===0){
      var comma=line.lastIndexOf(','),hdr=comma<0?line:line.substr(0,comma);
      info={title:comma<0?'':strip(line.substr(comma+1)),group:getAttribute(hdr,'group-title'),logo:getAttribute(hdr,'tvg-logo')};
    }else if(line.indexOf('#EXTGRP:')===0){group=strip(line.substr(8));if(info&&!info.group)info.group=group;}
    else if(line.charAt(0)!=='#'&&info){
      var u=line;if(isHttp(u)||/^rt[ms]p:\/\//i.test(u)){
        var g=info.group||group||'Sin categoria';
        arr.push({title:info.title||'Contenido '+(arr.length+1),group:g,logo:isHttp(info.logo)?info.logo:'',url:u,kind:guessKind(g,info.title,u)});
      }info=null;group='';
    }
  }
  return arr;
}
function getM3U(n,force){
  var c=config(n),url=strip(playlists[n].url);
  if(!isHttp(url))throw new Error('Agrega la URL M3U en los ajustes de la lista '+(n+1)+'.');
  if(!force&&cache[n]&&cache[n].url===url)return cache[n].items;
  var arr;
  try{arr=parseM3U(http.request(url,{headers:{'User-Agent':'Movian/7 IPTVRoger/0.4.0'}}).toString());}
  catch(e){throw new Error('No se pudo descargar o interpretar la lista M3U.');}
  cache[n]={url:url,items:arr};return arr;
}
function xtItems(n,c,kind,id){
  var x=xcache(n,c),key=kind+':'+id;
  if(x.lists[key])return x.lists[key];
  var data=xtCall(c,kindAction(kind,'items'),id==='all'?null:{category_id:id});
  if(Object.prototype.toString.call(data)!=='[object Array]')throw new Error('Este servidor no devolvio el catalogo esperado.');
  // Conservar solo el ultimo catalogo para limitar RAM en PS3.
  x.lists={};x.lists[key]=data;return data;
}
function xtStream(c,kind,e){
  var id=(kind==='series')?e.id:e.stream_id;
  if(!id)return '';
  var ext=kind==='live'?(c.liveFmt==='m3u8'?'m3u8':'ts'):strip(e.container_extension||'mp4').toLowerCase();
  if(!/^[a-z0-9]{2,5}$/.test(ext))ext='mp4';
  var route=kind==='live'?'live':(kind==='movies'?'movie':'series');
  return c.base+'/'+route+'/'+enc(c.user)+'/'+enc(c.pass)+'/'+enc(id)+'.'+ext;
}
function xtIcon(e,kind){
  var logo=kind==='series'?(e.cover||e.stream_icon):(e.stream_icon||e.cover);
  if(typeof logo==='string' && logo.indexOf('//')===0)logo='http:'+logo;
  return isHttp(logo)?logo:ICON;
}
function xtTitle(e,kind){return strip(kind==='series'?(e.name||e.title):(e.name||e.title))||'Sin titulo';}
function seriesInfo(n,c,id){
  var x=xcache(n,c),key=String(id);
  if(x.series[key])return x.series[key];
  var o=xtCall(c,'get_series_info',{series_id:id});
  if(!o||!o.episodes)throw new Error('El servidor no devolvio episodios de esta serie.');
  x.series={};x.series[key]=o;return o;
}
function seasons(info){var o=[];for(var s in info.episodes)if(info.episodes.hasOwnProperty(s))o.push(s);
  o.sort(function(a,b){return Number(a)-Number(b);});return o;
}

service.create('IPTV ROGER',PREFIX+':start','video',true,ICON);
settings.globalSettings(PREFIX,'IPTV ROGER - Listas M3U y Xtream',ICON,
  'Puedes configurar M3U o Xtream Codes para cada lista. Las credenciales se guardan localmente.');
settings.createInfo('info',ICON,'IPTV ROGER 0.4.0 - Movian 7. Introduce la direccion M3U o los datos Xtream. Las listas no se incluyen.');
for(var n=0;n<3;n++)(function(i){
  settings.createDivider('LISTA '+(i+1));
  var setting_name = settings.createString('name'+i,'Lista '+(i+1)+' - nombre',playlists[i].name,function(v){playlists[i].name=strip(v)||'Mi lista '+(i+1);});
  var setting_url = settings.createString('url'+i,'Lista '+(i+1)+' - enlace M3U (opcional)','',function(v){playlists[i].url=strip(v);reset(i);});
  var setting_xtserver = settings.createString('xtserver'+i,'Lista '+(i+1)+' - servidor Xtream (opcional)','',function(v){playlists[i].server=strip(v);reset(i);});
  var setting_xtuser = settings.createString('xtuser'+i,'Lista '+(i+1)+' - usuario Xtream','',function(v){playlists[i].user=strip(v);reset(i);});
  var setting_xtpass = settings.createString('xtpass'+i,'Lista '+(i+1)+' - clave Xtream','',function(v){playlists[i].pass=strip(v);reset(i);});
  var setting_xtfmt = settings.createString('xtfmt'+i,'Lista '+(i+1)+' - formato de TV Xtream (ts o m3u8)','ts',function(v){playlists[i].liveFmt=strip(v).toLowerCase()==='m3u8'?'m3u8':'ts';reset(i);});
  // Leer valor persistido incluso si esta version de Movian no llama callback al iniciar.
  if(setting_name && typeof setting_name.value!=='undefined')playlists[i].name=strip(setting_name.value)||playlists[i].name;
  if(setting_url && typeof setting_url.value!=='undefined')playlists[i].url=strip(setting_url.value);
  if(setting_xtserver && typeof setting_xtserver.value!=='undefined')playlists[i].server=strip(setting_xtserver.value);
  if(setting_xtuser && typeof setting_xtuser.value!=='undefined')playlists[i].user=strip(setting_xtuser.value);
  if(setting_xtpass && typeof setting_xtpass.value!=='undefined')playlists[i].pass=strip(setting_xtpass.value);
  if(setting_xtfmt && typeof setting_xtfmt.value!=='undefined')playlists[i].liveFmt=strip(setting_xtfmt.value).toLowerCase()==='m3u8'?'m3u8':'ts';
})(n);

new page.Route(PREFIX+':testvideo',function(p){
  try{playVideo(p,{title:'Prueba IPTV ROGER - video HLS',logo:ICON,
    url:'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'},PREFIX+':testvideo');}
  catch(e){p.error('Error en la prueba de video: '+e.message);p.loading=false;}
});
// Inicio visual: mosaico simple que usa la cuadrícula NATIVA de Movian 7.
// No inyectamos vistas GLW no comprobadas que puedan romper la instalación.
function configuredIndex(){
  for(var i=0;i<3;i++) {
    var c=config(i);
    if(c.mode==='xtream' || isHttp(c.url))return i;
  }
  return -1;
}
new page.Route(PREFIX+':start',function(p){
  startPage(p,'IPTV ROGER');
  addDir(p,PREFIX+':quick:live','TV en vivo','Abre los canales de tu lista principal',ART.tv);
  addDir(p,PREFIX+':quick:movies','Peliculas','Catalogo de peliculas con portadas',ART.movies);
  addDir(p,PREFIX+':quick:series','Series','Temporadas y episodios',ART.series);
  addDir(p,PREFIX+':favorites','Favoritos','Tu contenido guardado',ART.favs);
  addDir(p,PREFIX+':lists','Mis listas','Configura y administra hasta tres listas',ART.lists);
  addDir(p,PREFIX+':testvideo','Prueba de video','HLS publico para comprobar el reproductor',ART.test);
  addDir(p,PREFIX+':instructions','Como configurar','Guia breve para M3U y Xtream',ART.info);
  p.loading=false;
});
new page.Route(PREFIX+':quick:(live|movies|series)',function(p,kind){
  var n=configuredIndex();
  if(n<0){
    startPage(p,'Configura tu IPTV');
    addDir(p,PREFIX+':lists','Abrir mis listas','Primero agrega el enlace o las credenciales en Ajustes de Movian',ART.lists);
    addDir(p,PREFIX+':instructions','Como configurar','Instrucciones para activar tu servicio',ART.info);
  } else {
    try{
      var mode=resolveMode(n);
      p.redirect(PREFIX+(mode==='xtream'?':xtype:':':type:')+n+':'+kind);
    }catch(e){p.error('No se pudo abrir el catalogo: '+e.message);}
  }
  p.loading=false;
});
new page.Route(PREFIX+':lists',function(p){
  startPage(p,'Mis listas IPTV');
  for(var i=0;i<3;i++){
    var l=playlists[i],c=config(i),active=(c.mode==='xtream'||isHttp(c.url));
    addDir(p,PREFIX+':list:'+i,l.name,active?'Lista configurada: Abrir TV, peliculas y series':'Sin configurar. Usa Ajustes > IPTV ROGER.',ART.lists);
  }
  addDir(p,PREFIX+':instructions','Como configurar','M3U y Xtream Codes',ART.info);
  p.loading=false;
});
new page.Route(PREFIX+':instructions',function(p){
  startPage(p,'Guia IPTV ROGER');
  addSep(p,'Paso 1','Entra en Ajustes de Movian > IPTV ROGER');
  addSep(p,'Paso 2: M3U','Pega el enlace completo en el campo URL M3U de Lista 1');
  addSep(p,'Paso 2: Xtream','O escribe servidor, usuario y contrasena para la Lista 1');
  addSep(p,'Paso 3','Regresa a IPTV ROGER y abre TV, Peliculas o Series');
  addDir(p,PREFIX+':lists','Revisar mis listas','Listas disponibles',ART.lists);
  addDir(p,PREFIX+':testvideo','Probar reproductor HLS','Comprobar video sin necesidad de lista',ART.test);
  p.loading=false;
});
new page.Route(PREFIX+':list:([0-2])',function(p,v){
  var n=Number(v);startPage(p,playlists[n].name);
  try{
    var mode=resolveMode(n);
    if(mode==='xtream'){
      addDir(p,PREFIX+':xtype:'+n+':live','TV en vivo','Canales por categoria',ART.tv);
      addDir(p,PREFIX+':xtype:'+n+':movies','Peliculas','Catalogo con posters',ART.movies);
      addDir(p,PREFIX+':xtype:'+n+':series','Series','Temporadas y episodios',ART.series);
      addSep(p,'Conexion: Xtream Codes','Las caratulas dependen del proveedor.');
    }else{
      var arr=getM3U(n,false),count={live:0,movies:0,series:0};
      for(var i=0;i<arr.length;i++)count[arr[i].kind]++;
      addDir(p,PREFIX+':type:'+n+':live','TV en vivo ('+count.live+')','Canales por categoria',ART.tv);
      addDir(p,PREFIX+':type:'+n+':movies','Peliculas ('+count.movies+')','Peliculas con caratulas',ART.movies);
      addDir(p,PREFIX+':type:'+n+':series','Series ('+count.series+')','Series y episodios',ART.series);
      addSep(p,'Conexion: M3U','La separacion depende de los grupos de tu lista.');
    }
    addDir(p,PREFIX+':refresh:'+n,'Actualizar catalogo','Descargar de nuevo la informacion',ART.update);
  }catch(e){p.error('No se pudo abrir esta lista: '+e.message);}p.loading=false;
});
new page.Route(PREFIX+':refresh:([0-2])',function(p,v){var n=Number(v);reset(n);p.redirect(PREFIX+':list:'+n);});
new page.Route(PREFIX+':type:([0-2]):(live|movies|series)',function(p,v,kind){
  var n=Number(v);startPage(p,kind==='live'?'TV en vivo':(kind==='movies'?'Peliculas':'Series'));
  try{var arr=getM3U(n,false),groups={},order=[];
    for(var i=0;i<arr.length;i++)if(arr[i].kind===kind){var g=arr[i].group;
      if(typeof groups[g]==='undefined'){groups[g]=0;order.push(g);}groups[g]++;}
    order.sort();for(i=0;i<order.length;i++){g=order[i];addDir(p,PREFIX+':group:'+n+':'+kind+':'+enc(g),g+' ('+groups[g]+')','Explorar portadas',ART[kind]);}
    if(!order.length)addSep(p,'No hay elementos','Prueba con otro tipo de contenido.');
  }catch(e){p.error(e.message);}p.loading=false;
});
new page.Route(PREFIX+':group:([0-2]):(live|movies|series):(.*)',function(p,v,kind,gpart){
  var n=Number(v),group=dec(gpart);startPage(p,group);
  try{var arr=getM3U(n,false),idx=[];
    for(var i=0;i<arr.length;i++)if(arr[i].kind===kind&&arr[i].group===group)idx.push(i);
    paginate(p,idx,function(k){addVideo(p,arr[k],PREFIX+':play:'+n+':'+k,false);});
  }catch(e){p.error(e.message);}p.loading=false;
});
new page.Route(PREFIX+':play:([0-2]):([0-9]+)',function(p,v,id){
  try{var arr=getM3U(Number(v),false),item=arr[Number(id)];if(!item)throw new Error('Actualiza la lista.');
    playVideo(p,item,PREFIX+':play:'+v+':'+id);
  }catch(e){p.error('Error de reproduccion: '+e.message);p.loading=false;}
});

new page.Route(PREFIX+':xtype:([0-2]):(live|movies|series)',function(p,v,kind){
  var n=Number(v),c=config(n),title=kind==='live'?'TV en vivo':(kind==='movies'?'Peliculas':'Series');startPage(p,title);
  try{var cats=xtCategories(n,c,kind);
    if(!cats.length)addDir(p,PREFIX+':xgroup:'+n+':'+kind+':all','Todos','Explorar todo el contenido',ART[kind]);
    for(var i=0;i<cats.length;i++){
      var id=strip(cats[i].category_id),name=strip(cats[i].category_name)||'Sin nombre';
      if(id)addDir(p,PREFIX+':xgroup:'+n+':'+kind+':'+enc(id),name,'Ver catalogo',ART[kind]);
    }
  }catch(e){p.error('No se pudieron cargar las categorias: '+e.message);}p.loading=false;
});
new page.Route(PREFIX+':xgroup:([0-2]):(live|movies|series):(.*)',function(p,v,kind,catpart){
  var n=Number(v),id=dec(catpart),c=config(n);startPage(p,'Catalogo - '+(kind==='live'?'TV':(kind==='movies'?'Peliculas':'Series')));
  try{var arr=xtItems(n,c,kind,id),indexes=[];for(var i=0;i<arr.length&&i<LIMIT;i++)indexes.push(i);
    paginate(p,indexes,function(idx){var e=arr[idx],t=xtTitle(e,kind),icon=xtIcon(e,kind);
      if(kind==='series')addDir(p,PREFIX+':xseries:'+n+':'+enc(e.series_id),t,'Ver temporadas',icon);
      else addVideo(p,{title:t,logo:icon,group:kind,url:xtStream(c,kind,e)},
        PREFIX+':xplay:'+n+':'+kind+':'+enc(id)+':'+idx,false);
    });
  }catch(e){p.error('No se pudo abrir el catalogo: '+e.message);}p.loading=false;
});
new page.Route(PREFIX+':xplay:([0-2]):(live|movies):(.*):([0-9]+)',function(p,v,kind,catpart,pos){
  try{var n=Number(v),c=config(n),id=dec(catpart),arr=xtItems(n,c,kind,id),e=arr[Number(pos)];
    if(!e)throw new Error('Actualiza el catalogo.');
    var u=xtStream(c,kind,e);if(!u)throw new Error('No hay enlace de video.');
    playVideo(p,{title:xtTitle(e,kind),logo:xtIcon(e,kind),url:u},
      PREFIX+':xplay:'+n+':'+kind+':'+catpart+':'+pos);
  }catch(e){p.error('No se pudo reproducir: '+e.message);p.loading=false;}
});
new page.Route(PREFIX+':xseries:([0-2]):(.*)',function(p,v,sid){
  var n=Number(v),id=dec(sid),c=config(n);startPage(p,'Temporadas');
  try{var info=seriesInfo(n,c,id),ss=seasons(info);
    for(var i=0;i<ss.length;i++)addDir(p,PREFIX+':xseason:'+n+':'+enc(id)+':'+enc(ss[i]),
      'Temporada '+ss[i]+' ('+info.episodes[ss[i]].length+')','Ver episodios');
    if(!ss.length)addSep(p,'No hay temporadas disponibles','');
  }catch(e){p.error('No se pudo abrir la serie: '+e.message);}p.loading=false;
});
new page.Route(PREFIX+':xseason:([0-2]):([^:]+):([^:]+)',function(p,v,sid,sp){
  var n=Number(v),id=dec(sid),s=dec(sp),c=config(n);startPage(p,'Temporada '+s);
  try{var info=seriesInfo(n,c,id),eps=info.episodes[s]||[];
    paginate(p,eps,function(ep,j){
      var icon=ep.info&&isHttp(ep.info.movie_image)?ep.info.movie_image:ICON;
      addVideo(p,{title:strip(ep.title)||'Episodio '+(j+1),logo:icon,group:'Temporada '+s,
        url:xtStream(c,'series',ep)},PREFIX+':xepisode:'+n+':'+enc(id)+':'+enc(s)+':'+j,false);
    });
  }catch(e){p.error('No se pudieron cargar los episodios: '+e.message);}p.loading=false;
});
new page.Route(PREFIX+':xepisode:([0-2]):([^:]+):([^:]+):([0-9]+)',function(p,v,sid,sp,idx){
  try{var n=Number(v),c=config(n),id=dec(sid),s=dec(sp),info=seriesInfo(n,c,id),ep=(info.episodes[s]||[])[Number(idx)];
    if(!ep)throw new Error('Episodio no disponible.');
    var u=xtStream(c,'series',ep);if(!u)throw new Error('No hay enlace para este episodio.');
    playVideo(p,{title:ep.title||'Episodio',url:u,logo:ep.info&&ep.info.movie_image||ICON},
      PREFIX+':xepisode:'+n+':'+sid+':'+sp+':'+idx);
  }catch(e){p.error('Error al reproducir el episodio: '+e.message);p.loading=false;}
});
new page.Route(PREFIX+':favorites',function(p){
  startPage(p,'Favoritos');var arr=favs();
  if(!arr.length)addSep(p,'Sin favoritos','Marca contenido desde las opciones de un video.');
  paginate(p,arr,function(e,i){addVideo(p,e,PREFIX+':favplay:'+i,true);});p.loading=false;
});
new page.Route(PREFIX+':favplay:([0-9]+)',function(p,idx){
  try{var item=favs()[Number(idx)];if(!item)throw new Error('No encontrado.');
    playVideo(p,item,PREFIX+':favplay:'+idx);
  }catch(e){p.error(e.message);p.loading=false;}
});
